resource "oci_kms_vault" "ocm_secrets" {
  display_name   = "ocm-secrets"
  count          = local.migration_secrets_compartment_available ? 1 : 0
  compartment_id = local.migration_secrets_compartment_id
  vault_type     = "DEFAULT"

  defined_tags = merge({
    "${local.ocm_migration_tag_namespace}.${local.version_tag}"        = local.version_value,
    "${local.ocm_migration_tag_namespace}.${local.resource_level_tag}" = local.resource_level_values[1]
    },
    local.migration_from_vmware == true ? local.vmware_defined_tags : {},
    local.migration_from_aws == true ? local.aws_defined_tags : {},
    local.migration_to_olvm == true ? local.olvm_defined_tags : {}
  )
  depends_on = [time_sleep.tags_availability_delay]
}

resource "oci_kms_key" "ocm_key" {
  count          = local.migration_secrets_compartment_available ? 1 : 0
  display_name   = "ocm-key"
  compartment_id = local.migration_secrets_compartment_id
  key_shape {
    algorithm = "AES"
    length    = "32"
  }
  management_endpoint = oci_kms_vault.ocm_secrets[0].management_endpoint

  defined_tags = merge({
    "${local.ocm_migration_tag_namespace}.${local.version_tag}"        = local.version_value,
    "${local.ocm_migration_tag_namespace}.${local.resource_level_tag}" = local.resource_level_values[1]
    },
    local.migration_from_vmware == true ? local.vmware_defined_tags : {},
    local.migration_from_aws == true ? local.aws_defined_tags : {},
    local.migration_to_olvm == true ? local.olvm_defined_tags : {}
  )
  depends_on = [time_sleep.tags_availability_delay]
}
